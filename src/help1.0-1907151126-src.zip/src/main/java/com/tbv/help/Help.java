package com.tbv.help;

import java.io.IOException;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.java.JavaPlugin;

public final class Help extends JavaPlugin {
	String cs;
	String L1="MikeWu597的服务器";
	String L2="/info 1 -服务器介绍";
	String L3="/info 2 -服务器指令帮助";
	//String L4="";
	
	@Override
    public void onEnable() {
        // 插件载入时要执行的代码（略）
		getLogger().info(">>TBVHelp Iajm Yi Qiys");
    }
    
    @Override
    public void onDisable() {
        // 插件卸载时要执行的代码（略）
    	getLogger().info(">>TBVHelp Iajm Yi T;ys");
    }
    
    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] Xdmu) {
    	boolean L1Exe=false;
    	try
    	{
    		cs=Xdmu[0];
    	}
    	catch (Exception e)
    	{
    		cs="0";
    	}
    	
        if (cmd.getName().equalsIgnoreCase("info")) { // 如果玩家输入了/basic则执行如下内容... 
        	if (cs!="0" && cs!="2\0")
        	{
        		Bukkit.getServer().dispatchCommand(Bukkit.getConsoleSender(), "tellraw "+sender.getName()+" {\"text\":\"\"}");
            	Bukkit.getServer().dispatchCommand(Bukkit.getConsoleSender(), "tellraw "+sender.getName()+" {\"text\":\"————————\"}");
            	Bukkit.getServer().dispatchCommand(Bukkit.getConsoleSender(), "tellraw "+sender.getName()+" {\"text\":\""+L2+"\",\"color\":\"gold\",\"bold\":\"true\",\"underlined\":\"true\"}");
            	Bukkit.getServer().dispatchCommand(Bukkit.getConsoleSender(), "tellraw "+sender.getName()+" {\"text\":\"  -MikeWu597的服务器建立于2019年5月29日。\n-它拥有垃圾的配置，在许多人同时传送的时候往往能够给予玩家崩服的极致体验。\n-本服的优秀服主曾获全国Minecraft瞎搞大赛MCBBS赛区删帖奖励。\n-本服集跑酷、生存、装逼、作死于一体，浓缩凝聚于一台辣鸡的机器。\n-在玩耍过后，不要忘记给服务器竖个大拇指哦！\",\"color\":\"aqua\",\"bold\":\"false\",\"underlined\":\"false\"}");
            	Bukkit.getServer().dispatchCommand(Bukkit.getConsoleSender(), "tellraw "+sender.getName()+" {\"text\":\"\n-版本：1.12.2\n-正版验证√\n-群号：554082366\n-配置：1核2G 1Mbps带宽\",\"color\":\"aqua\",\"bold\":\"false\",\"underlined\":\"false\"}");
            	Bukkit.getServer().dispatchCommand(Bukkit.getConsoleSender(), "tellraw "+sender.getName()+" {\"text\":\"————————\"}");
            	Bukkit.getServer().dispatchCommand(Bukkit.getConsoleSender(), "tellraw "+sender.getName()+" {\"text\":\"\"}");
            	L1Exe=true;
            	return true;
        	}
        	if (cs=="0")
        	{
        		//sender.sendMessage("Info");
        		Bukkit.getServer().dispatchCommand(Bukkit.getConsoleSender(), "tellraw "+sender.getName()+" {\"text\":\"\"}");
        		Bukkit.getServer().dispatchCommand(Bukkit.getConsoleSender(), "tellraw "+sender.getName()+" {\"text\":\"————————\"}");
        		Bukkit.getServer().dispatchCommand(Bukkit.getConsoleSender(), "tellraw "+sender.getName()+" {\"text\":\""+L1+"\",\"color\":\"gold\",\"bold\":\"true\",\"underlined\":\"true\"}");
        		Bukkit.getServer().dispatchCommand(Bukkit.getConsoleSender(), "tellraw "+sender.getName()+" {\"text\":\"  "+L2+"\",\"color\":\"aqua\",\"bold\":\"false\",\"underlined\":\"false\"}");
        		Bukkit.getServer().dispatchCommand(Bukkit.getConsoleSender(), "tellraw "+sender.getName()+" {\"text\":\"  "+L3+"\",\"color\":\"aqua\",\"bold\":\"false\",\"underlined\":\"false\"}");
        		Bukkit.getServer().dispatchCommand(Bukkit.getConsoleSender(), "tellraw "+sender.getName()+" {\"text\":\"————————\"}");
        		Bukkit.getServer().dispatchCommand(Bukkit.getConsoleSender(), "tellraw "+sender.getName()+" {\"text\":\"\"}");
        		return true;
        	}
        	return true;
        } //如果以上内容成功执行，则返回true 
        // 如果执行失败，则返回false.
        return false;
    }
}