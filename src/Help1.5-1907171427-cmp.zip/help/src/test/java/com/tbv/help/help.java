package com.tbv.help;

import org.bukkit.plugin.java.JavaPlugin;

public final class help extends JavaPlugin {
	
	@Override
    public void onEnable() {
        // 插件载入时要执行的代码（略）
		getLogger().info(">>TBVHelp Iajm Yi Qiys");
    }
    
    @Override
    public void onDisable() {
        // 插件卸载时要执行的代码（略）
    	getLogger().info(">>TBVHelp Iajm Yi T;ys");
    	
    }
}