package com.tbv.help;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.java.JavaPlugin;

public final class Help extends JavaPlugin {
	String cs;
	String L1="MikeWu597的服务器";
	String L2="/info 1 -服务器介绍";
	String L3="/info 2 -服务器指令帮助";
	//String L4="";
	
	@Override
    public void onEnable() {
        // 插件载入时要执行的代码（略）
		getLogger().info(">>TBVHelp Iajm Yi Qiys");
    }
    
    @Override
    public void onDisable() {
        // 插件卸载时要执行的代码（略）
    	getLogger().info(">>TBVHelp Iajm Yi T;ys");
    }
    
    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] Xdmu) {
    	
    	try
    	{
    		cs=Xdmu[0];
    	}
    	catch (Exception e)
    	{
    		cs="0";
    		Bukkit.getServer().dispatchCommand(Bukkit.getConsoleSender(), "tellraw "+sender.getName()+" {\"text\":\"\"}");
    		Bukkit.getServer().dispatchCommand(Bukkit.getConsoleSender(), "tellraw "+sender.getName()+" {\"text\":\"————————\"}");
    		Bukkit.getServer().dispatchCommand(Bukkit.getConsoleSender(), "tellraw "+sender.getName()+" {\"text\":\""+L1+"\",\"color\":\"gold\",\"bold\":\"true\",\"underlined\":\"true\"}");
    		Bukkit.getServer().dispatchCommand(Bukkit.getConsoleSender(), "tellraw "+sender.getName()+" {\"text\":\"  "+L2+"\",\"color\":\"aqua\",\"bold\":\"false\",\"underlined\":\"false\"}");
    		Bukkit.getServer().dispatchCommand(Bukkit.getConsoleSender(), "tellraw "+sender.getName()+" {\"text\":\"  "+L3+"\",\"color\":\"aqua\",\"bold\":\"false\",\"underlined\":\"false\"}");
    		Bukkit.getServer().dispatchCommand(Bukkit.getConsoleSender(), "tellraw "+sender.getName()+" {\"text\":\"————————\"}");
    		return true;
    	}
    	
        if (cmd.getName().equalsIgnoreCase("info")) { // 如果玩家输入了/basic则执行如下内容... 
        	//sender.sendMessage("cs=|"+cs+"|");
        	if (cs.equalsIgnoreCase("1"))
        	{
        		Bukkit.getServer().dispatchCommand(Bukkit.getConsoleSender(), "tellraw "+sender.getName()+" {\"text\":\"\"}");
            	Bukkit.getServer().dispatchCommand(Bukkit.getConsoleSender(), "tellraw "+sender.getName()+" {\"text\":\"————————\"}");
            	Bukkit.getServer().dispatchCommand(Bukkit.getConsoleSender(), "tellraw "+sender.getName()+" {\"text\":\""+L2+"\",\"color\":\"gold\",\"bold\":\"true\",\"underlined\":\"true\"}");
            	Bukkit.getServer().dispatchCommand(Bukkit.getConsoleSender(), "tellraw "+sender.getName()+" {\"text\":\"  -MikeWu597的服务器建立于2019年5月29日。\n-它拥有垃圾的配置，在许多人同时传送的时候往往能够给予玩家崩服的极致体验。\n-本服的优秀服主曾获全国Minecraft瞎搞大赛MCBBS赛区删帖奖励。\n-本服集跑酷、生存、装逼、作死于一体，浓缩凝聚于一台辣鸡的机器。\n-在玩耍过后，不要忘记给服务器竖个大拇指哦！\",\"color\":\"aqua\",\"bold\":\"false\",\"underlined\":\"false\"}");
            	Bukkit.getServer().dispatchCommand(Bukkit.getConsoleSender(), "tellraw "+sender.getName()+" {\"text\":\"\n-版本：1.14.3\n-正版验证√\n-群号：554082366\n-配置：1核2G 1Mbps带宽\",\"color\":\"aqua\",\"bold\":\"false\",\"underlined\":\"false\"}");
            	Bukkit.getServer().dispatchCommand(Bukkit.getConsoleSender(), "tellraw "+sender.getName()+" {\"text\":\"————————\"}");
            	
            	return true;
        	}
        	if (cs.equalsIgnoreCase("2"))
        	{
        		Bukkit.getServer().dispatchCommand(Bukkit.getConsoleSender(), "tellraw "+sender.getName()+" {\"text\":\"\"}");
            	Bukkit.getServer().dispatchCommand(Bukkit.getConsoleSender(), "tellraw "+sender.getName()+" {\"text\":\"————————\"}");
            	Bukkit.getServer().dispatchCommand(Bukkit.getConsoleSender(), "tellraw "+sender.getName()+" {\"text\":\""+L3+"\",\"color\":\"gold\",\"bold\":\"true\",\"underlined\":\"true\"}");
            	Bukkit.getServer().dispatchCommand(Bukkit.getConsoleSender(), "tellraw "+sender.getName()+" {\"text\":\""+
            			"传送类：\n" + 
            			"  /goto world 前往跑酷主大厅\n" + 
            			"  /goto survival 前往生存世界\n" + 
            			"  /goto amp 前往放大化生存世界\n" + 
            			"  /sethome [名称] 设定家\n" + 
            			"  /delhome [名称] 删除家\n" + 
            			"  /home [名称] 传送回家（多人同时使用易卡服）\n" + 
            			"\n" + 
            			"养老类：\n" + 
            			"  /sign 每日签到得点券\n" + 
            			"  /p give <玩家> <数目> 给予一位玩家点券 \n" + 
            			"  /p lead 查看服务器玩家点券排行\n" + 
            			"\n" + 
            			"随身物品全服通用，请自觉维持游戏平衡\",\"color\":\"aqua\",\"bold\":\"false\",\"underlined\":\"false\"}");
            	Bukkit.getServer().dispatchCommand(Bukkit.getConsoleSender(), "tellraw "+sender.getName()+" {\"text\":\"————————\"}");
            	
            	return true;
        	}
        	return true;
        } //如果以上内容成功执行，则返回true 
        // 如果执行失败，则返回false.
        return false;
    }
}